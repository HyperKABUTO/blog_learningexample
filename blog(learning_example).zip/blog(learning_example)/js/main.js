;$(function()
{
   'use strict';
   
   var sidebar = $('#sidebar'),
	   mask = $('.mask'),
	   backButton = $('.back-to-top'),
	   sidebar_trigger = $('#sidebar_trigger');

   sidebar_trigger.on('click',function()
   {
       mask.fadeIn();
	   //sidebar.animate({'right':0});
	   sidebar.css('right',0);
   });

   mask.on('click',function()
   {
	   mask.fadeOut();
	   sidebar.css('right',-sidebar.width());/* sidebar.width()����һ�����ͣ����Ҫ�Ӹ��� */
   });

   backButton.on('click',function()
   {
	   $('html,body').animate({scrollTop:0},500);
   });

   $(window).scroll(function()
   {
		if($(window).scrollTop() > $(window).height())
	    {
			backButton.fadeIn();
		}
		else
	    {
			backButton.fadeOut();
		}
   });//�������¼�

   $(window).trigger('scroll');/* ʹ�����Լ�����scroll�¼� */
})